package fileio;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public
class Sort {
    private String rating;
    private String duration;
}
